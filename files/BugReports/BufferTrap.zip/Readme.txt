Trap example
First-chance exception at 0x7789F073 (ntdll.dll) in BufferTrap.exe: 0xC0000005: Access violation writing location 0x00DCE000.

Stack
 	ntdll.dll!_memmove()	Unknown
 	KernelBase.dll!_CopyRectangle@24()	Unknown
 	KernelBase.dll!_ReadConsoleOutputInternal@24()	Unknown
 	KernelBase.dll!_ReadConsoleOutputW@20()	Unknown
>	BufferTrap.exe!wmain(int argc=1, wchar_t * * argv=0x00dcbfe8) Line 23	C++

Variables
+		pLine	0x00dc5490 {Char={UnicodeChar=63 '?' AsciiChar=63 '?' } Attributes=28362 }	_CHAR_INFO *
+		bufSize	{X=80 Y=1 }	_COORD
+		bufCoord	{X=0 Y=0 }	_COORD
+		rgn	{Left=0 Top=9998 Right=79 Bottom=9998}	_SMALL_RECT

Look, "((CHAR_INFO*)0x00DCE000 - pLine) == 8924" in this example! Real value may be vary...
